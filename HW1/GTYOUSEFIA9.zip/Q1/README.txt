***IMPORTANT***
Do not modify the contents of the pygexf directory